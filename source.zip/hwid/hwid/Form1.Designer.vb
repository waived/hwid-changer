﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PvForm1 = New hwid.PVForm()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnSet = New System.Windows.Forms.Button()
        Me.btnGen = New System.Windows.Forms.Button()
        Me.txtNew = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCurrent = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PvEmbeddedButton1 = New hwid.PVEmbeddedButton()
        Me.PvForm1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PvForm1
        '
        Me.PvForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.PvForm1.Controls.Add(Me.Label3)
        Me.PvForm1.Controls.Add(Me.btnSet)
        Me.PvForm1.Controls.Add(Me.btnGen)
        Me.PvForm1.Controls.Add(Me.txtNew)
        Me.PvForm1.Controls.Add(Me.Label2)
        Me.PvForm1.Controls.Add(Me.txtCurrent)
        Me.PvForm1.Controls.Add(Me.Label1)
        Me.PvForm1.Controls.Add(Me.PvEmbeddedButton1)
        Me.PvForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PvForm1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.PvForm1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(149, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.PvForm1.Location = New System.Drawing.Point(0, 0)
        Me.PvForm1.MinimumSize = New System.Drawing.Size(305, 150)
        Me.PvForm1.Name = "PvForm1"
        Me.PvForm1.Size = New System.Drawing.Size(351, 273)
        Me.PvForm1.TabIndex = 0
        Me.PvForm1.Text = "HWID changer by Waived"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(12, 210)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(327, 55)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "https://github.com/waived"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnSet
        '
        Me.btnSet.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.btnSet.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnSet.Location = New System.Drawing.Point(182, 177)
        Me.btnSet.Name = "btnSet"
        Me.btnSet.Size = New System.Drawing.Size(139, 29)
        Me.btnSet.TabIndex = 7
        Me.btnSet.Text = "Set new ID"
        Me.btnSet.UseVisualStyleBackColor = False
        '
        'btnGen
        '
        Me.btnGen.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.btnGen.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnGen.Location = New System.Drawing.Point(34, 177)
        Me.btnGen.Name = "btnGen"
        Me.btnGen.Size = New System.Drawing.Size(139, 29)
        Me.btnGen.TabIndex = 6
        Me.btnGen.Text = "Generate new"
        Me.btnGen.UseVisualStyleBackColor = False
        '
        'txtNew
        '
        Me.txtNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.txtNew.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNew.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtNew.Location = New System.Drawing.Point(34, 136)
        Me.txtNew.Name = "txtNew"
        Me.txtNew.ReadOnly = True
        Me.txtNew.Size = New System.Drawing.Size(287, 18)
        Me.txtNew.TabIndex = 5
        Me.txtNew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(34, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(287, 19)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "New hardware ID"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'txtCurrent
        '
        Me.txtCurrent.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.txtCurrent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCurrent.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtCurrent.Location = New System.Drawing.Point(34, 74)
        Me.txtCurrent.Name = "txtCurrent"
        Me.txtCurrent.ReadOnly = True
        Me.txtCurrent.Size = New System.Drawing.Size(287, 18)
        Me.txtCurrent.TabIndex = 3
        Me.txtCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(34, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(287, 19)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "System hardware ID"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'PvEmbeddedButton1
        '
        Me.PvEmbeddedButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(23, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.PvEmbeddedButton1.Font = New System.Drawing.Font("Trebuchet MS", 10.0!)
        Me.PvEmbeddedButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(149, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.PvEmbeddedButton1.Location = New System.Drawing.Point(299, 3)
        Me.PvEmbeddedButton1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.PvEmbeddedButton1.Name = "PvEmbeddedButton1"
        Me.PvEmbeddedButton1.Size = New System.Drawing.Size(47, 20)
        Me.PvEmbeddedButton1.TabIndex = 0
        Me.PvEmbeddedButton1.Text = "X"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(351, 273)
        Me.Controls.Add(Me.PvForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(305, 150)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.PvForm1.ResumeLayout(False)
        Me.PvForm1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PvForm1 As PVForm
    Friend WithEvents PvEmbeddedButton1 As PVEmbeddedButton
    Friend WithEvents btnGen As Button
    Friend WithEvents txtNew As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtCurrent As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSet As Button
    Friend WithEvents Label3 As Label
End Class
