﻿Imports System.IO
Imports System.Text
Imports Microsoft.VisualBasic.Logging
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        _getCurrent()
    End Sub
    Private Sub PvEmbeddedButton1_Click(sender As Object, e As EventArgs) Handles PvEmbeddedButton1.Click
        Me.Close()
    End Sub

    Private Function _getCurrent()
        Me.CheckForIllegalCrossThreadCalls = False
        If My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\IDConfigDB\Hardware Profiles\0001", "HwProfileGuid", Nothing) Is Nothing Then
            Me.Hide()
            MsgBox("Error! Unable to modify windows registry. Exiting...")
            Me.Close()
        Else
            Dim getValue = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\IDConfigDB\Hardware Profiles\0001", "HwProfileGuid", Nothing)
            txtCurrent.Text = getValue
        End If
    End Function

    Private Sub btnGen_Click(sender As Object, e As EventArgs) Handles btnGen.Click
        txtNew.Text = "{" + System.Guid.NewGuid.ToString() + "}"
    End Sub

    Private Sub btnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click
        If Not String.IsNullOrEmpty(txtNew.Text) Then
            Try
                Dim fs As FileStream = File.Create("original.txt")
                Dim info As Byte() = New UTF8Encoding(True).GetBytes(txtCurrent.Text)
                fs.Write(info, 0, info.Length)
                fs.Close()
            Catch : End Try

            Try
                My.Computer.Registry.SetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\IDConfigDB\Hardware Profiles\0001", "HwProfileGuid", txtNew.Text)
                'Dim getValue = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\IDConfigDB\Hardware Profiles\0001", "HwProfileGuid", Nothing)

                _getCurrent()
                txtNew.Clear()

                MessageBox.Show("New Hardware ID has been set! Original backed up to 'original.txt'")
            Catch ex As Exception
                MessageBox.Show("Critical error spoofing HWID!", "Alert!")
            End Try
        Else
            MessageBox.Show("A new HWID must first be generated before the original can be changed!", "Alert!")
        End If
    End Sub
End Class
